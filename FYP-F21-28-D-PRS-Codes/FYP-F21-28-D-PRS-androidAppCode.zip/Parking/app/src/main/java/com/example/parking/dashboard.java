package com.example.parking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.Window;
import android.view.WindowManager;
import android.content.SharedPreferences;
import androidx.drawerlayout.widget.DrawerLayout;


import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.auth.FirebaseAuth;

public class dashboard extends AppCompatActivity {

    CardView available;
    private FirebaseAuth mAuth;
    ImageView lmenu;
    DrawerLayout drwr;
    Button logout;

    SharedPreferences mPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        mPreferences=getSharedPreferences("com.example.sharedprefdrwrb",MODE_PRIVATE);
        editor=mPreferences.edit();

        mAuth= FirebaseAuth.getInstance();
        drwr=findViewById(R.id.drwr);
        lmenu=findViewById(R.id.lmenu);
        available = findViewById(R.id.available);

        logout=findViewById(R.id.logout);

        //To open left Sidebar on DashBoard
        lmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(drwr.isDrawerOpen(Gravity.LEFT))
                    drwr.closeDrawer(Gravity.LEFT);
                else
                    drwr.openDrawer(Gravity.LEFT);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(dashboard.this,LoginActivity.class));
            }
        });



        available.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(dashboard.this,availablespot.class));
            }
        });
    }
}