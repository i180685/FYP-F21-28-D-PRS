package com.example.parking;

import android.app.Activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.util.Patterns;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;



public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth ;
    EditText email,pass;
    Button signin;
    TextView register,forgotpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth= FirebaseAuth.getInstance();
        email = findViewById(R.id.email);
        pass  = findViewById(R.id.pass);
        signin = findViewById(R.id.login);
        register = findViewById(R.id.register);
        forgotpass = findViewById(R.id.forget);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(LoginActivity.this,dashboard.class));

                String uemail= email.getText().toString().trim();
                String upass= pass.getText().toString().trim();

                if(uemail.isEmpty()){
                    email.setError("Email is required!");
                    email.requestFocus();
                    return;
                }
                if(!Patterns.EMAIL_ADDRESS.matcher(uemail).matches()){
                    email.setError("Please Provide Valid Email Address!");
                    email.requestFocus();
                    return;
                }

                if(upass.isEmpty()){
                    pass.setError("Password is required!");
                    pass.requestFocus();
                    return;
                }
                if(upass.length()<6)
                {
                    pass.setError("Min Password length should be 6 charachters!");
                    pass.requestFocus();
                    return;
                }

                mAuth.signInWithEmailAndPassword(uemail,upass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            if(user.isEmailVerified())  //validation if user has verified registered email or not
                            {
                                startActivity(new Intent(LoginActivity.this,dashboard.class));
                                Toast.makeText(LoginActivity.this, "Sign In Successful", Toast.LENGTH_LONG).show();
                            }
                            else
                            {
                                //user.sendEmailVerification();
                                Toast.makeText(LoginActivity.this, "Check Your Email To Verify Your Account!", Toast.LENGTH_LONG).show();
                            }


                        }
                        else
                        {
                            Toast.makeText(LoginActivity.this, "Failed To Login! Please Check Your Credentials ", Toast.LENGTH_LONG).show();
                        }
                    }
                });



            }
        });


        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, forgetpassword.class));
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (LoginActivity.this,RegisterActivity.class));
            }
        });
    }




}
