package com.example.parking;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class availablespot extends AppCompatActivity {

    CardView spot1,spot2,spot3,spot4,spot5,spot6,spot7,spot8,spot9,spot10,spot11,spot12,spot13,spot14,spot15,spot16;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_availablespot);


        back= findViewById(R.id.back_button);

        spot1 = findViewById(R.id.spot1);
        spot2 = findViewById(R.id.spot2);
        spot3 = findViewById(R.id.spot3);
        spot4 = findViewById(R.id.spot4);
        spot5 = findViewById(R.id.spot5);
        spot6 = findViewById(R.id.spot6);
        spot7 = findViewById(R.id.spot7);
        spot8 = findViewById(R.id.spot8);
        spot9 = findViewById(R.id.spot9);
        spot10 = findViewById(R.id.spot10);
        spot11 = findViewById(R.id.spot11);
        spot12 = findViewById(R.id.spot12);
        spot13 = findViewById(R.id.spot13);
        spot14 = findViewById(R.id.spot14);
        spot15 = findViewById(R.id.spot15);
        spot16 = findViewById(R.id.spot16);

        spot1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               spot1.setBackgroundResource(R.color.red);
            }
        });

        spot2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot2.setBackgroundResource(R.color.red);
            }
        });
        spot3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot3.setBackgroundResource(R.color.red);
            }
        });
        spot4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot4.setBackgroundResource(R.color.red);
            }
        });

        spot5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot5.setBackgroundResource(R.color.red);
            }
        });

        spot6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot6.setBackgroundResource(R.color.red);
            }
        });

        spot7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot7.setBackgroundResource(R.color.red);
            }
        });
        spot8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot8.setBackgroundResource(R.color.red);
            }
        });
        spot9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot9.setBackgroundResource(R.color.red);
            }
        });

        spot10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot10.setBackgroundResource(R.color.red);
            }
        });

        spot11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot11.setBackgroundResource(R.color.red);
            }
        });

        spot12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot12.setBackgroundResource(R.color.red);
            }
        });
        spot13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot13.setBackgroundResource(R.color.red);
            }
        });
        spot14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot14.setBackgroundResource(R.color.red);
            }
        });

        spot15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot15.setBackgroundResource(R.color.red);
            }
        });

        spot16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spot16.setBackgroundResource(R.color.red);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(availablespot.this,dashboard.class));
            }
        });



    }
}